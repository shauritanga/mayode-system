import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { ActivityType } from '@prisma/client';
import { Type } from 'class-transformer';
import {
  IsArray,
  IsBoolean,
  IsDateString,
  IsEnum,
  IsNotEmpty,
  IsNumber,
  IsObject,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';

export class RiceProtocolTaskDefinitionDto {
  @ApiProperty() @IsString() @IsNotEmpty() key: string;
  @ApiProperty() @IsString() @IsNotEmpty() title: string;
  @ApiProperty() @IsString() @IsNotEmpty() guidance: string;
  @ApiProperty({
    description:
      'Days from planting; harvest tasks may use daysFromHarvest instead.',
  })
  @IsOptional()
  @IsNumber()
  daysFromPlanting?: number;
  @ApiPropertyOptional() @IsOptional() @IsNumber() daysFromHarvest?: number;
  @ApiPropertyOptional({
    enum: ActivityType,
    description:
      'Completing the task records this kind of crop activity. Leave empty for tasks that are not field work.',
  })
  @IsOptional()
  @IsEnum(ActivityType)
  activityType?: ActivityType;
  @ApiPropertyOptional()
  @IsOptional()
  @IsObject()
  requiredMeasurements?: Record<
    string,
    { label: string; unit?: string; min?: number; max?: number }
  >;
  @ApiPropertyOptional() @IsOptional() @IsBoolean() evidenceRequired?: boolean;
}

export class UpdateRiceProtocolDto {
  @ApiProperty() @IsString() @IsNotEmpty() name: string;
  @ApiPropertyOptional({
    description:
      'Planting date this calendar is laid out from (YYYY-MM-DD); empty clears it. Leave out to keep the current one.',
    nullable: true,
  })
  @IsOptional()
  @IsDateString()
  seasonStart?: string | null;
  @ApiProperty({ type: [RiceProtocolTaskDefinitionDto] })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => RiceProtocolTaskDefinitionDto)
  taskDefinitions: RiceProtocolTaskDefinitionDto[];
}

export class CompleteRiceCalendarTaskDto {
  @ApiPropertyOptional({
    description: 'Values keyed by the protocol measurement keys.',
  })
  @IsOptional()
  @IsObject()
  measurements?: Record<string, string | number>;
  @ApiPropertyOptional({ type: [String] })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  photoUrls?: string[];
  @ApiPropertyOptional() @IsOptional() @IsString() description?: string;
  @ApiPropertyOptional({ description: 'Defaults to now.' })
  @IsOptional()
  @IsDateString()
  completedAt?: string;
}

export class RescheduleRiceCalendarTaskDto {
  @ApiProperty({ description: 'New due date for this crop-cycle task.' })
  @IsDateString()
  dueDate: string;

  @ApiPropertyOptional({
    description:
      'Optional reason, for example variety stage or field-officer/VBAA advice.',
  })
  @IsOptional()
  @IsString()
  reason?: string;
}
