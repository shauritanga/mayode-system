import { hasGrant } from '../auth/role-access';
import {
  Injectable,
  ForbiddenException,
  NotFoundException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { UserRole, VerificationStatus } from '@prisma/client';

export interface RequestUser {
  id: string;
  role: UserRole;
  mamcosId?: string | null;
  /** Populated by JwtStrategy; drives matrix authorization. */
  customRole?: {
    isActive: boolean;
    isSystem?: boolean;
    permissions: { action: string; resource: { key: string } }[];
  } | null;
}

/**
 * OwnershipService — row-level authorization. Explicitly permitted staff can access the resource; a FARMER
 * may only touch resources for farms they are actively assigned to operate.
 * `Farm.farmerId` is retained as legacy/import metadata; it is not the access
 * authority for renter-operated AMCOS farms. Call these from services before
 * performing a mutation.
 */
@Injectable()
export class OwnershipService {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Resolves which single AMCOS a user's data access should be confined to.
   * Only SUPER_ADMIN is platform-wide (null = unscoped, no filter applied).
   * Everyone else is scoped to their own cooperative via `user.mamcosId`
   * (resolved once per request in JwtStrategy from their staff/farmer
   * profile) — null there too if they have no cooperative attached (e.g. an
   * AUDITOR/BUYER account), which preserves today's unscoped behavior for
   * those roles rather than silently hiding everything from them.
   */
  resolveTenantMamcosId(user: RequestUser): string | null {
    if (user.role === UserRole.SUPER_ADMIN) {
      return null;
    }
    return user.mamcosId ?? null;
  }

  private isPrivileged(user: RequestUser, resource: string): boolean {
    if (user.role === UserRole.SUPER_ADMIN) return true;
    // Farmer profiles remain ownership-scoped even when their role has grants.
    return user.role !== UserRole.FARMER && !!user.customRole?.isActive &&
      !user.customRole.isSystem && user.customRole.permissions.some((p) => p.resource.key === resource);
  }

  /** Service checks use the same explicit grants as route guards. */
  passesMatrix(user: RequestUser, resource: string, action: string): boolean {
    return hasGrant(user, resource, action);
  }

  /** Resolve the farmer.id owned by the requesting user (or null if not a farmer). */
  private async farmerIdForUser(userId: string): Promise<string | null> {
    const farmer = await this.prisma.farmer.findUnique({
      where: { userId },
      select: { id: true },
    });
    return farmer?.id ?? null;
  }

  async assertFarmerAccess(user: RequestUser, farmerId: string): Promise<void> {
    if (this.isPrivileged(user, 'farmers')) return;
    const ownFarmerId = await this.farmerIdForUser(user.id);
    if (ownFarmerId !== farmerId) {
      throw new ForbiddenException(
        'You can only access your own farmer records',
      );
    }
  }

  async assertFarmAccess(user: RequestUser, farmId: string): Promise<void> {
    if (this.isPrivileged(user, 'farms')) return;
    const ownFarmerId = await this.farmerIdForUser(user.id);
    if (!ownFarmerId) {
      throw new ForbiddenException(
        'A farmer profile is required to access a farm',
      );
    }

    // Primary path: verified seasonal operator (owner-operated or renter).
    const assignment = await this.prisma.seasonalFarmAssignment.findFirst({
      where: {
        farmId,
        activeFarmerId: ownFarmerId,
        status: VerificationStatus.VERIFIED,
        farmingSeason: { status: 'ACTIVE' },
      },
      select: { id: true },
    });
    if (assignment) return;

    // Owner of a personally registered farm may access without an assignment
    // (bootstrap for self-operate / first crop cycle). AMCOS/renter farms keep
    // Farm.farmerId as metadata and still require a verified assignment above.
    const farm = await this.prisma.farm.findUnique({
      where: { id: farmId },
      select: { farmerId: true },
    });
    if (farm?.farmerId === ownFarmerId) return;

    throw new ForbiddenException(
      'You need an active, field-verified seasonal assignment to access this farm',
    );
  }

  async assertPlotAccess(user: RequestUser, plotId: string): Promise<void> {
    if (this.isPrivileged(user, 'plots')) return;
    const plot = await this.prisma.plot.findUnique({
      where: { id: plotId },
      select: { farmId: true },
    });
    if (!plot) throw new NotFoundException(`Plot with ID ${plotId} not found`);
    await this.assertFarmAccess(user, plot.farmId);
  }
}
