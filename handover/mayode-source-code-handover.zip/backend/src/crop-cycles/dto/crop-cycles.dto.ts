import {
  IsUUID,
  Min,
  IsString,
  IsOptional,
  IsNumber,
  IsInt,
  IsEnum,
  IsArray,
  IsObject,
  IsDateString,
  IsNotEmpty,
  Max,
} from 'class-validator';
import {
  ApiProperty,
  ApiPropertyOptional,
  PartialType,
  OmitType,
} from '@nestjs/swagger';
import {
  CropCycleStatus,
  ActivityType,
  CycleIrrigationType,
  ProductionMethod,
  RiceGrowthStage,
} from '@prisma/client';

export class CreateCropCycleDto {
  @ApiProperty({
    example: 'farm-uuid-1234',
    description: 'ID of the farm where the crop cycle takes place',
  })
  @IsString()
  @IsNotEmpty()
  farmId: string;

  @ApiPropertyOptional({
    example: 'farmer-uuid-5678',
    description:
      "Owning farmer. Ignored for farmer-role requests — always derived from the farm to prevent spoofing; usable by staff creating on a farmer's behalf.",
  })
  @IsString()
  @IsOptional()
  farmerId?: string;

  @ApiProperty({
    example: '2026/2027 Masika',
    description: 'Farming season identifier',
  })
  @IsString()
  @IsOptional()
  season?: string;

  @ApiPropertyOptional({
    example: 'SARO 5 (TXD 306)',
    description: 'Rice variety planted',
  })
  @IsString()
  @IsOptional()
  riceVariety?: string;

  @ApiPropertyOptional({
    description:
      "The rice variety chosen from the admin-managed list. Its calendar and maturity time decide the farmer's activities.",
  })
  @IsUUID()
  @IsOptional()
  riceVarietyId?: string;

  @ApiPropertyOptional({
    example: '2026-12-15T08:00:00Z',
    description: 'Planting date',
  })
  @IsDateString()
  @IsOptional()
  plantingDate?: string;

  @ApiPropertyOptional({
    example: '2027-05-20T08:00:00Z',
    description: 'Expected harvest date',
  })
  @IsDateString()
  @IsOptional()
  expectedHarvest?: string;

  @ApiPropertyOptional({
    example: 4500.5,
    description: 'Estimated yield in kilograms',
  })
  @IsNumber()
  @Min(0)
  @IsOptional()
  estimatedYieldKg?: number;

  @ApiPropertyOptional({
    description:
      'The farming season (registration window) this crop belongs to. Its name is used as the season when none is typed.',
  })
  @IsUUID()
  @IsOptional()
  farmingSeasonId?: string;

  @ApiPropertyOptional({ example: 2.5, description: 'Area planted, hectares' })
  @IsNumber()
  @Min(0.01)
  @Max(100000)
  @IsOptional()
  areaPlantedHa?: number;

  @ApiPropertyOptional({ example: 60, description: 'Seed used, kilograms' })
  @IsNumber()
  @Min(0)
  @IsOptional()
  seedQuantityKg?: number;

  @ApiPropertyOptional({ enum: ProductionMethod })
  @IsEnum(ProductionMethod)
  @IsOptional()
  productionMethod?: ProductionMethod;

  @ApiPropertyOptional({ enum: CycleIrrigationType })
  @IsEnum(CycleIrrigationType)
  @IsOptional()
  irrigationType?: CycleIrrigationType;

  @ApiPropertyOptional({ enum: RiceGrowthStage })
  @IsEnum(RiceGrowthStage)
  @IsOptional()
  growthStage?: RiceGrowthStage;
}

export class UpdateCropCycleDto {
  @ApiPropertyOptional({ example: '2026/2027 Masika' })
  @IsString()
  @IsOptional()
  season?: string;

  @ApiPropertyOptional({ example: 'SARO 5 (TXD 306)' })
  @IsString()
  @IsOptional()
  riceVariety?: string;

  @ApiPropertyOptional({
    description:
      "Changing it swaps the pending activities to the new variety's calendar.",
  })
  @IsUUID()
  @IsOptional()
  riceVarietyId?: string;

  @ApiPropertyOptional({ example: '2026-12-15T08:00:00Z' })
  @IsDateString()
  @IsOptional()
  plantingDate?: string;

  @ApiPropertyOptional({ example: '2027-05-20T08:00:00Z' })
  @IsDateString()
  @IsOptional()
  expectedHarvest?: string;

  @ApiPropertyOptional({
    example: '2027-05-25T10:00:00Z',
    description: 'Actual harvest date',
  })
  @IsDateString()
  @IsOptional()
  harvestDate?: string;

  @ApiPropertyOptional({ example: 4500.5 })
  @IsNumber()
  @Min(0)
  @IsOptional()
  estimatedYieldKg?: number;

  @ApiPropertyOptional({
    example: 4850.0,
    description: 'Actual yield harvested in kilograms',
  })
  @IsNumber()
  @Min(0)
  @IsOptional()
  actualYieldKg?: number;

  @ApiPropertyOptional({ example: 'ACTIVE', enum: CropCycleStatus })
  @IsEnum(CropCycleStatus)
  @IsOptional()
  status?: CropCycleStatus;

  @ApiPropertyOptional({
    description:
      'The farming season (registration window) this crop belongs to. Its name is used as the season when none is typed.',
  })
  @IsUUID()
  @IsOptional()
  farmingSeasonId?: string;

  @ApiPropertyOptional({ example: 2.5, description: 'Area planted, hectares' })
  @IsNumber()
  @Min(0.01)
  @Max(100000)
  @IsOptional()
  areaPlantedHa?: number;

  @ApiPropertyOptional({ example: 60, description: 'Seed used, kilograms' })
  @IsNumber()
  @Min(0)
  @IsOptional()
  seedQuantityKg?: number;

  @ApiPropertyOptional({ enum: ProductionMethod })
  @IsEnum(ProductionMethod)
  @IsOptional()
  productionMethod?: ProductionMethod;

  @ApiPropertyOptional({ enum: CycleIrrigationType })
  @IsEnum(CycleIrrigationType)
  @IsOptional()
  irrigationType?: CycleIrrigationType;

  @ApiPropertyOptional({ enum: RiceGrowthStage })
  @IsEnum(RiceGrowthStage)
  @IsOptional()
  growthStage?: RiceGrowthStage;

  @ApiPropertyOptional({ description: 'Note kept with a stage change' })
  @IsString()
  @IsOptional()
  stageNote?: string;
}

export class CreateActivityLogDto {
  @ApiProperty({
    example: 'crop-cycle-uuid-1234',
    description: 'ID of the active crop cycle',
  })
  @IsString()
  @IsNotEmpty()
  cropCycleId: string;

  @ApiProperty({
    example: 'LAND_PREPARATION',
    enum: ActivityType,
    description: 'Type of farming activity performed',
  })
  @IsEnum(ActivityType)
  activityType: ActivityType;

  @ApiProperty({
    example: '2026-11-10T09:00:00Z',
    description: 'Timestamp of the activity',
  })
  @IsDateString()
  activityDate: string;

  @ApiPropertyOptional({
    example:
      'Completed initial deep plowing and harrowing using hired tractor.',
  })
  @IsString()
  @IsOptional()
  description?: string;

  @ApiPropertyOptional({
    example: {
      fertilizerType: 'NPK 20:10:10',
      quantityKg: 50,
      applicationMethod: 'Broadcasting',
    },
    description: 'JSON object detailing farming inputs utilized',
  })
  @IsObject()
  @IsOptional()
  inputsUsed?: Record<string, any>;

  @ApiPropertyOptional({
    example: 4,
    description: 'Number of laborers employed for this activity',
  })
  @IsInt()
  @Min(0)
  @IsOptional()
  laborWorkers?: number;

  @ApiPropertyOptional({
    example: 32.5,
    description: 'Total labor man-hours spent',
  })
  @IsNumber()
  @Min(0)
  @IsOptional()
  laborHours?: number;

  @ApiPropertyOptional({
    example: 2,
    description: 'Family members who contributed labour',
  })
  @IsInt()
  @Min(0)
  @IsOptional()
  familyLaborCount?: number;

  @ApiPropertyOptional({
    example: 3,
    description: 'Paid workers who contributed labour',
  })
  @IsInt()
  @Min(0)
  @IsOptional()
  hiredLaborCount?: number;

  @ApiPropertyOptional({
    example: 90000,
    description: 'Total paid labour wage in TZS',
  })
  @IsNumber()
  @Min(0)
  @IsOptional()
  laborWageTotal?: number;

  @ApiPropertyOptional({
    example: ['https://example.com/activity1.jpg'],
    description: 'Activity photo proof URLs',
  })
  @IsArray()
  @IsString({ each: true })
  @IsOptional()
  photoUrls?: string[];

  @ApiPropertyOptional({ example: -8.8925 })
  @IsNumber()
  @IsOptional()
  gpsLatitude?: number;

  @ApiPropertyOptional({ example: 34.5035 })
  @IsNumber()
  @IsOptional()
  gpsLongitude?: number;

  @ApiPropertyOptional({
    description: 'Plot of the farm the work was done on; leave empty for the whole farm',
  })
  @IsString()
  @IsOptional()
  plotId?: string;

  @ApiPropertyOptional({ example: 'NPK 20:10:10', description: 'Main input used' })
  @IsString()
  @IsOptional()
  inputName?: string;

  @ApiPropertyOptional({ example: 50 })
  @IsNumber()
  @Min(0)
  @IsOptional()
  inputQuantity?: number;

  @ApiPropertyOptional({ example: 'kg' })
  @IsString()
  @IsOptional()
  inputUnit?: string;

  @ApiPropertyOptional({ example: 120000, description: 'Total cost of the activity in TZS' })
  @IsNumber()
  @Min(0)
  @IsOptional()
  cost?: number;

  @ApiPropertyOptional({ example: 'Rain delayed the work by two days.' })
  @IsString()
  @IsOptional()
  remarks?: string;

  @ApiPropertyOptional({
    description: 'Field officer who did or supervised the work (staff entering on their behalf)',
  })
  @IsString()
  @IsOptional()
  fieldOfficerId?: string;
}

export class UpdateActivityLogDto extends PartialType(
  OmitType(CreateActivityLogDto, ['cropCycleId'] as const),
) {}

export class CalendarQueryDto {
  @ApiPropertyOptional({
    description:
      'ISO date, inclusive lower bound; defaults to start of current month',
  })
  @IsDateString()
  @IsOptional()
  from?: string;

  @ApiPropertyOptional({
    description:
      'ISO date, inclusive upper bound; defaults to end of current month',
  })
  @IsDateString()
  @IsOptional()
  to?: string;
}
