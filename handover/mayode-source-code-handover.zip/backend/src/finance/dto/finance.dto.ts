import {
  Min,
  IsString,
  IsOptional,
  IsNumber,
  IsEnum,
  IsDateString,
  IsNotEmpty,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { CostCategory, InputPaymentStatus, RevenueType } from '@prisma/client';

export class CreateInputCostDto {
  @ApiProperty({
    example: 'crop-cycle-uuid-1234',
    description: 'ID of the active crop cycle',
  })
  @IsString()
  @IsNotEmpty()
  cropCycleId: string;

  @ApiProperty({
    example: 'FERTILIZER',
    enum: CostCategory,
    description: 'Category of production cost',
  })
  @IsEnum(CostCategory)
  category: CostCategory;

  @ApiProperty({ example: 'NPK 20:10:10 Fertilizer Bags' })
  @IsString()
  @IsNotEmpty()
  itemName: string;

  @ApiPropertyOptional({ example: 10 })
  @IsNumber()
  @Min(0)
  @IsOptional()
  quantity?: number;

  @ApiPropertyOptional({ example: 'Bags (50kg)' })
  @IsString()
  @IsOptional()
  unit?: string;

  @ApiPropertyOptional({
    example: 75000.0,
    description: 'Price per unit in TZS',
  })
  @IsNumber()
  @Min(0)
  @IsOptional()
  unitPrice?: number;

  @ApiProperty({ example: 750000.0, description: 'Total cost incurred in TZS' })
  @IsNumber()
  @Min(0)
  totalCost: number;

  @ApiPropertyOptional({
    example: 'Mbarali Agro-Suppliers Ltd',
    description: 'Free-text supplier name (legacy field)',
  })
  @IsString()
  @IsOptional()
  supplier?: string;

  @ApiPropertyOptional({
    example: 'supplier-uuid-1234',
    description: 'ID of a registered Supplier record',
  })
  @IsString()
  @IsOptional()
  supplierId?: string;

  @ApiPropertyOptional({ example: 'PENDING', enum: InputPaymentStatus })
  @IsEnum(InputPaymentStatus)
  @IsOptional()
  paymentStatus?: InputPaymentStatus;

  @ApiPropertyOptional({
    example: 'loan-record-uuid-1234',
    description: 'LoanRecord this input purchase is financed against',
  })
  @IsString()
  @IsOptional()
  loanRecordId?: string;

  @ApiPropertyOptional({ example: 'https://example.com/receipt1.jpg' })
  @IsString()
  @IsOptional()
  receiptUrl?: string;

  @ApiProperty({
    example: '2026-11-15T10:00:00Z',
    description: 'Date the cost was incurred',
  })
  @IsDateString()
  dateIncurred: string;
}

export class CreateRevenueDto {
  @ApiProperty({
    example: 'crop-cycle-uuid-1234',
    description: 'ID of the active crop cycle',
  })
  @IsString()
  @IsNotEmpty()
  cropCycleId: string;

  @ApiProperty({
    example: 'FAIRTRADE_SALE',
    enum: RevenueType,
    description: 'Type of revenue sale',
  })
  @IsEnum(RevenueType)
  revenueType: RevenueType;

  @ApiProperty({
    example: 4850.0,
    description: 'Quantity of rice sold in kilograms',
  })
  @IsNumber()
  @Min(0)
  quantityKg: number;

  @ApiProperty({
    example: 1200.0,
    description: 'Selling price per kilogram in TZS',
  })
  @IsNumber()
  @Min(0)
  pricePerKg: number;

  @ApiProperty({
    example: 5820000.0,
    description: 'Total gross revenue in TZS',
  })
  @IsNumber()
  @Min(0)
  totalRevenue: number;

  @ApiPropertyOptional({
    example: 242500.0,
    description: 'Fairtrade premium earned in TZS',
  })
  @IsNumber()
  @Min(0)
  @IsOptional()
  fairtradePremium?: number;

  @ApiPropertyOptional({
    example: 'buyer-uuid-5678',
    description: 'ID of the verified buyer',
  })
  @IsString()
  @IsOptional()
  buyerId?: string;

  @ApiProperty({ example: '2027-05-30T14:00:00Z', description: 'Date of sale' })
  @IsDateString()
  saleDate: string;
}
